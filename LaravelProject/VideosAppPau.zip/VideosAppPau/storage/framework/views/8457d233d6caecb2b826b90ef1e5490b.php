<?php $__env->startSection('content'); ?>
    <h1>Videos</h1>
    <ul>
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(url('/videos', $video->id)); ?>">
                    <?php echo e($video->title); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.videos-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/Escriptori/LaravelPauCangas/LaravelProject/VideosAppPau/resources/views/videos/index.blade.php ENDPATH**/ ?>